def my_cool_test():
    print('it works')

__version__ = "0.2.2"
__author__ = 'Dawei Wang'
__credits__ = 'Kellogg School of Management'
